# -*- coding: utf-8 -*-
"""
package
"""
from .simple_mqtt import app
